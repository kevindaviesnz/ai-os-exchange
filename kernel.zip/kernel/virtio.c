#include "os_virtio.h"
#include "os_ipc.h"

extern void uart_print(const char *str);
extern void mmu_map_framebuffer(uint64_t phys_addr, uint64_t size);
extern void kpanic(const char *msg);
extern void uart_print_hex(uint32_t val);
extern void ipc_kernel_send(uint32_t target_id, uint32_t type, uint8_t *payload, uint32_t length);

/* --- Global Pointers --- */
static uint64_t dma_heap_curr = 0x50000000ULL;

/* GPU */
static volatile struct virtq_desc *gpu_desc;
static volatile struct virtq_avail *gpu_avail;
static volatile struct virtq_used *gpu_used;
static uint16_t gpu_last_used_idx = 0;
static uint64_t gpu_mmio_base = 0;
static uint16_t global_desc_idx = 0;

static uint64_t g_fb_phys = 0;
static uint32_t g_fb_size = 0;
static struct virtio_gpu_transfer_to_host_2d *g_req_tx;
static struct virtio_gpu_ctrl_hdr *g_resp_tx;
static struct virtio_gpu_resource_flush *g_req_flush;
static struct virtio_gpu_ctrl_hdr *g_resp_flush;

/* Block */
static volatile struct virtq_desc *blk_desc;
static volatile struct virtq_avail *blk_avail;
static volatile struct virtq_used *blk_used;
static uint16_t blk_last_used_idx = 0;
static uint64_t blk_mmio_base = 0;
static uint16_t blk_global_desc_idx = 0;
static struct virtio_blk_req *blk_req_buf;
static uint8_t *blk_status_buf;

/* Input */
static volatile struct virtq_desc *in_desc;
static volatile struct virtq_avail *in_avail;
static volatile struct virtq_used *in_used;
static uint16_t in_last_used_idx = 0;
static uint64_t in_mmio_base = 0;
static struct virtio_input_event *in_events;
static int input_initialized = 0;

static const char keymap_lower[ 128 ] = {
    0, 0, '1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '-', '=', '\b',
    '\t', 'q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p', '[', ']', '\n',
    0, 'a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l', ';', '\'', '`',
    0, '\\', 'z', 'x', 'c', 'v', 'b', 'n', 'm', ',', '.', '/', 0,
    '*', 0, ' ', 0
};

uint64_t bump_allocate(uint32_t size, uint32_t align) {
    uint64_t addr = dma_heap_curr;
    if (addr % align != 0) {
        addr = (addr + align - 1) & ~((uint64_t)(align - 1));
    }
    dma_heap_curr = addr + size;
    for (uint32_t i = 0; i < size; i++) {
        ((volatile uint8_t *)addr)[ i ] = 0;
    }
    return addr;
}

int virtio_blk_read_sector(uint64_t sector, uint8_t *buffer) {
    if (!blk_mmio_base) return -1;

    blk_req_buf->type = VIRTIO_BLK_T_IN;
    blk_req_buf->reserved = 0;
    blk_req_buf->sector = sector;
    *blk_status_buf = 0xFF;

    uint16_t d0 = blk_global_desc_idx++ % VIRTQ_SIZE;
    uint16_t d1 = blk_global_desc_idx++ % VIRTQ_SIZE;
    uint16_t d2 = blk_global_desc_idx++ % VIRTQ_SIZE;

    blk_desc[ d0 ].addr  = (uint64_t)blk_req_buf;
    blk_desc[ d0 ].len   = sizeof(*blk_req_buf);
    blk_desc[ d0 ].flags = VIRTQ_DESC_F_NEXT;
    blk_desc[ d0 ].next  = d1;

    blk_desc[ d1 ].addr  = (uint64_t)buffer;
    blk_desc[ d1 ].len   = 512;
    blk_desc[ d1 ].flags = VIRTQ_DESC_F_NEXT | VIRTQ_DESC_F_WRITE;
    blk_desc[ d1 ].next  = d2;

    blk_desc[ d2 ].addr  = (uint64_t)blk_status_buf;
    blk_desc[ d2 ].len   = 1;
    blk_desc[ d2 ].flags = VIRTQ_DESC_F_WRITE;
    blk_desc[ d2 ].next  = 0;

    uint16_t avail_idx = blk_avail->idx;
    blk_avail->ring[ avail_idx % VIRTQ_SIZE ] = d0;

    for (uint64_t a = (uint64_t)blk_req_buf & ~63ULL; a < (uint64_t)blk_req_buf + sizeof(*blk_req_buf); a += 64)
        __asm__ volatile("dc cvac, %0" :: "r"(a) : "memory");

    for (uint64_t a = (uint64_t)blk_desc & ~63ULL; a < (uint64_t)blk_desc + sizeof(struct virtq_desc) * VIRTQ_SIZE; a += 64)
        __asm__ volatile("dc cvac, %0" :: "r"(a) : "memory");

    for (uint64_t a = (uint64_t)&blk_avail->ring[ avail_idx % VIRTQ_SIZE ] & ~63ULL; a < (uint64_t)&blk_avail->idx + 2; a += 64)
        __asm__ volatile("dc cvac, %0" :: "r"(a) : "memory");

    __asm__ volatile("dsb sy" ::: "memory");

    blk_avail->idx = avail_idx + 1;
    __asm__ volatile("dc cvac, %0" :: "r"((uint64_t)&blk_avail->idx & ~63ULL) : "memory");
    __asm__ volatile("dsb sy" ::: "memory");

    volatile uint32_t *notify_reg = (volatile uint32_t *)(blk_mmio_base + VIRTIO_REG_QUEUE_NOTIFY);
    *notify_reg = 0;

    uint64_t used_line = (uint64_t)&blk_used->idx & ~63ULL;
    while (blk_used->idx == blk_last_used_idx) {
        __asm__ volatile("dc ivac, %0" :: "r"(used_line) : "memory");
        __asm__ volatile("dsb sy" ::: "memory");
    }
    blk_last_used_idx++;

    for (uint64_t a = (uint64_t)buffer & ~63ULL; a < (uint64_t)buffer + 512; a += 64)
        __asm__ volatile("dc ivac, %0" :: "r"(a) : "memory");
        
    __asm__ volatile("dc ivac, %0" :: "r"((uint64_t)blk_status_buf & ~63ULL) : "memory");
    __asm__ volatile("dsb sy" ::: "memory");

    return (*blk_status_buf == 0) ? 0 : -1;
}

void virtio_input_poll(void) {
    if (!in_mmio_base) return;

    __asm__ volatile("dc ivac, %0" :: "r"((uint64_t)&in_used->idx & ~63ULL) : "memory");
    __asm__ volatile("dsb sy" ::: "memory");

    uint16_t used_idx = in_used->idx;
    
    while (in_last_used_idx != used_idx) {
        uint32_t ring_idx = in_last_used_idx % VIRTQ_SIZE;
        
        __asm__ volatile("dc ivac, %0" :: "r"((uint64_t)&in_used->ring[ ring_idx ] & ~63ULL) : "memory");
        __asm__ volatile("dsb sy" ::: "memory");
        
        uint32_t id = in_used->ring[ ring_idx ].id;

        struct virtio_input_event *evt = &in_events[ id ];

        __asm__ volatile("dc ivac, %0" :: "r"((uint64_t)evt & ~63ULL) : "memory");
        __asm__ volatile("dsb sy" ::: "memory");

        if (evt->type == VIRTIO_INPUT_EV_KEY && evt->value == 1) {
            if (evt->code < 128) {
                char ascii_char = keymap_lower[ evt->code ];
                if (ascii_char) {
                    uint8_t payload[ 1 ] = { (uint8_t)ascii_char };
                    ipc_kernel_send(SYS_MOD_GUI_SHELL, 1, payload, 1);
                }
            }
        }

        uint16_t avail_idx = in_avail->idx;
        in_desc[ id ].len = sizeof(struct virtio_input_event);
        in_desc[ id ].flags = VIRTQ_DESC_F_WRITE;
        
        /* QA FIX: Flush the replenished descriptor to physical RAM */
        __asm__ volatile("dc cvac, %0" :: "r"((uint64_t)&in_desc[ id ] & ~63ULL) : "memory");
        __asm__ volatile("dsb sy" ::: "memory");

        in_avail->ring[ avail_idx % VIRTQ_SIZE ] = id;
        
        __asm__ volatile("dsb sy" ::: "memory");
        in_avail->idx = avail_idx + 1;
        
        __asm__ volatile("dc cvac, %0" :: "r"((uint64_t)&in_avail->idx & ~63ULL) : "memory");
        __asm__ volatile("dsb sy" ::: "memory");

        in_last_used_idx++;
    }

    volatile uint32_t *notify_reg = (volatile uint32_t *)(in_mmio_base + VIRTIO_REG_QUEUE_NOTIFY);
    *notify_reg = 0;
}

uint32_t send_gpu_command(uint64_t request_phys,  uint32_t request_size,
                          uint64_t response_phys, uint32_t response_size) {

    uint16_t d0 = global_desc_idx++ % VIRTQ_SIZE;
    uint16_t d1 = global_desc_idx++ % VIRTQ_SIZE;

    gpu_desc[ d0 ].addr  = request_phys;
    gpu_desc[ d0 ].len   = request_size;
    gpu_desc[ d0 ].flags = VIRTQ_DESC_F_NEXT;
    gpu_desc[ d0 ].next  = d1;

    gpu_desc[ d1 ].addr  = response_phys;
    gpu_desc[ d1 ].len   = response_size;
    gpu_desc[ d1 ].flags = VIRTQ_DESC_F_WRITE;
    gpu_desc[ d1 ].next  = 0;

    uint16_t avail_idx = gpu_avail->idx;
    gpu_avail->ring[ avail_idx % VIRTQ_SIZE ] = d0;

    for (uint64_t a = request_phys & ~63ULL; a < request_phys + request_size; a += 64)
        __asm__ volatile("dc cvac, %0" :: "r"(a) : "memory");

    for (uint64_t a = (uint64_t)&gpu_desc[ d0 ] & ~63ULL;
         a < (uint64_t)&gpu_desc[ d1 ] + sizeof(struct virtq_desc); a += 64)
        __asm__ volatile("dc cvac, %0" :: "r"(a) : "memory");

    for (uint64_t a = (uint64_t)&gpu_avail->ring[ avail_idx % VIRTQ_SIZE ] & ~63ULL;
         a < (uint64_t)&gpu_avail->idx + 2; a += 64)
        __asm__ volatile("dc cvac, %0" :: "r"(a) : "memory");

    __asm__ volatile("dsb sy" ::: "memory");

    gpu_avail->idx = avail_idx + 1;
    __asm__ volatile("dc cvac, %0" :: "r"((uint64_t)&gpu_avail->idx & ~63ULL) : "memory");
    __asm__ volatile("dsb sy" ::: "memory");

    volatile uint32_t *notify_reg = (volatile uint32_t *)(gpu_mmio_base + VIRTIO_REG_QUEUE_NOTIFY);
    *notify_reg = 0;

    uint64_t used_line = (uint64_t)&gpu_used->idx & ~63ULL;
    while (gpu_used->idx == gpu_last_used_idx) {
        __asm__ volatile("dc ivac, %0" :: "r"(used_line) : "memory");
        __asm__ volatile("dsb sy" ::: "memory");
    }
    gpu_last_used_idx++;

    for (uint64_t a = response_phys & ~63ULL; a < response_phys + response_size; a += 64)
        __asm__ volatile("dc ivac, %0" :: "r"(a) : "memory");
    __asm__ volatile("dsb sy" ::: "memory");

    return ((struct virtio_gpu_ctrl_hdr *)response_phys)->type;
}

void virtio_gpu_flush(void) {
    if (!g_fb_phys) return;
    
    uint32_t resp_type;
    
    uint64_t addr = g_fb_phys & ~63ULL;
    uint64_t end  = g_fb_phys + g_fb_size;
    while (addr < end) {
        __asm__ volatile("dc cvac, %0" :: "r"(addr) : "memory");
        addr += 64;
    }
    __asm__ volatile("dsb sy" ::: "memory");

    resp_type = send_gpu_command((uint64_t)g_req_tx, sizeof(*g_req_tx), (uint64_t)g_resp_tx, sizeof(*g_resp_tx));
    if (resp_type != VIRTIO_GPU_RESP_OK_NODATA) {
        uart_print("[ ERROR ] GPU TRANSFER failed in flush syscall\n");
    }
    
    resp_type = send_gpu_command((uint64_t)g_req_flush, sizeof(*g_req_flush), (uint64_t)g_resp_flush, sizeof(*g_resp_flush));
    if (resp_type != VIRTIO_GPU_RESP_OK_NODATA) {
        uart_print("[ ERROR ] GPU FLUSH failed in flush syscall\n");
    }
}

void gpu_init(void) {
    uint32_t resp_type;
    uart_print("[ GPU ] Commencing VirtIO Handshake...\n");

    struct virtio_gpu_ctrl_hdr *req_info = (struct virtio_gpu_ctrl_hdr *)bump_allocate(sizeof(*req_info), 8);
    struct virtio_gpu_resp_display_info *resp_info = (struct virtio_gpu_resp_display_info *)bump_allocate(sizeof(*resp_info), 8);
    req_info->type = VIRTIO_GPU_CMD_GET_DISPLAY_INFO;
    resp_type = send_gpu_command((uint64_t)req_info, sizeof(*req_info), (uint64_t)resp_info, sizeof(*resp_info));
    if (resp_type != VIRTIO_GPU_RESP_OK_DISPLAY_INFO) kpanic("GPU: GET_DISPLAY_INFO failed");

    uint32_t fb_width  = resp_info->pmodes[ 0 ].r.width;
    uint32_t fb_height = resp_info->pmodes[ 0 ].r.height;
    if (fb_width == 0 || fb_height == 0) { fb_width = 1024; fb_height = 768; }
    
    g_fb_size = fb_width * fb_height * 4; 
    uart_print("[ GPU ] Display Info OK. Binding Resolution...\n");

    struct virtio_gpu_resource_create_2d *req_create = (struct virtio_gpu_resource_create_2d *)bump_allocate(sizeof(*req_create), 8);
    struct virtio_gpu_ctrl_hdr *resp_create = (struct virtio_gpu_ctrl_hdr *)bump_allocate(sizeof(*resp_create), 8);
    req_create->hdr.type = VIRTIO_GPU_CMD_RESOURCE_CREATE_2D; 
    req_create->resource_id = 1; 
    req_create->format = VIRTIO_GPU_FORMAT_B8G8R8X8_UNORM; 
    req_create->width = fb_width; 
    req_create->height = fb_height;
    resp_type = send_gpu_command((uint64_t)req_create, sizeof(*req_create), (uint64_t)resp_create, sizeof(*resp_create));
    if (resp_type != VIRTIO_GPU_RESP_OK_NODATA) kpanic("GPU: CREATE failed");

    g_fb_phys = bump_allocate(g_fb_size, 4096); 
    
    uint32_t attach_sz = sizeof(struct virtio_gpu_resource_attach_backing) + sizeof(struct virtio_gpu_mem_entry);
    struct virtio_gpu_resource_attach_backing *req_attach = (struct virtio_gpu_resource_attach_backing *)bump_allocate(attach_sz, 8);
    struct virtio_gpu_ctrl_hdr *resp_attach = (struct virtio_gpu_ctrl_hdr *)bump_allocate(sizeof(*resp_attach), 8);
    req_attach->hdr.type = VIRTIO_GPU_CMD_RESOURCE_ATTACH_BACKING;
    req_attach->resource_id = 1;
    req_attach->nr_entries = 1;
    struct virtio_gpu_mem_entry *entry = (struct virtio_gpu_mem_entry *)(req_attach + 1);
    entry->addr = g_fb_phys;
    entry->length = g_fb_size;
    entry->padding = 0;
    resp_type = send_gpu_command((uint64_t)req_attach, attach_sz, (uint64_t)resp_attach, sizeof(*resp_attach));
    if (resp_type != VIRTIO_GPU_RESP_OK_NODATA) kpanic("GPU: ATTACH failed");

    mmu_map_framebuffer(g_fb_phys, g_fb_size);

    struct virtio_gpu_set_scanout *req_scanout = (struct virtio_gpu_set_scanout *)bump_allocate(sizeof(*req_scanout), 8);
    struct virtio_gpu_ctrl_hdr *resp_scanout = (struct virtio_gpu_ctrl_hdr *)bump_allocate(sizeof(*resp_scanout), 8);
    req_scanout->hdr.type = VIRTIO_GPU_CMD_SET_SCANOUT; 
    req_scanout->r.x = 0; req_scanout->r.y = 0; 
    req_scanout->r.width = fb_width; req_scanout->r.height = fb_height; 
    req_scanout->scanout_id = 0; req_scanout->resource_id = 1;
    resp_type = send_gpu_command((uint64_t)req_scanout, sizeof(*req_scanout), (uint64_t)resp_scanout, sizeof(*resp_scanout));
    if (resp_type != VIRTIO_GPU_RESP_OK_NODATA) kpanic("GPU: SCANOUT failed");

    g_req_tx = (struct virtio_gpu_transfer_to_host_2d *)bump_allocate(sizeof(*g_req_tx), 8);
    g_resp_tx = (struct virtio_gpu_ctrl_hdr *)bump_allocate(sizeof(*g_resp_tx), 8);
    g_req_tx->hdr.type = VIRTIO_GPU_CMD_TRANSFER_TO_HOST_2D; 
    g_req_tx->r.x = 0; g_req_tx->r.y = 0; 
    g_req_tx->r.width = fb_width; g_req_tx->r.height = fb_height; 
    g_req_tx->offset = 0; g_req_tx->resource_id = 1; g_req_tx->padding = 0;

    g_req_flush = (struct virtio_gpu_resource_flush *)bump_allocate(sizeof(*g_req_flush), 8);
    g_resp_flush = (struct virtio_gpu_ctrl_hdr *)bump_allocate(sizeof(*g_resp_flush), 8);
    g_req_flush->hdr.type = VIRTIO_GPU_CMD_RESOURCE_FLUSH; 
    g_req_flush->r.x = 0; g_req_flush->r.y = 0; 
    g_req_flush->r.width = fb_width; g_req_flush->r.height = fb_height; 
    g_req_flush->resource_id = 1; g_req_flush->padding = 0;

    uart_print("[ GPU ] Handshake Complete! Screen should be active.\n");
}

void virtio_probe_and_init(void) {
    uart_print("[ KERNEL ] VirtIO probe: scanning 32 slots...\n");
    
    for (int i = 0; i < VIRTIO_MMIO_SLOT_COUNT; i++) {
        uint64_t base = VIRTIO_MMIO_BASE + (i * VIRTIO_MMIO_SLOT_SIZE);
        volatile uint32_t *magic   = (volatile uint32_t *)(base + 0x000);
        volatile uint32_t *version = (volatile uint32_t *)(base + 0x004);
        volatile uint32_t *devid   = (volatile uint32_t *)(base + 0x008);
        
        if (*magic == VIRTIO_MAGIC && *devid != 0) {
            
            if (*devid == VIRTIO_DEV_INPUT && !input_initialized) {
                input_initialized = 1;
                uart_print("[ KERNEL ] VirtIO Input found. Initializing queue...\n");
                in_mmio_base = base;
                
                volatile uint32_t *status = (volatile uint32_t *)(base + VIRTIO_REG_STATUS);
                volatile uint32_t *q_sel  = (volatile uint32_t *)(base + VIRTIO_REG_QUEUE_SEL);
                volatile uint32_t *q_num  = (volatile uint32_t *)(base + VIRTIO_REG_QUEUE_NUM);
                
                *status = 0; 
                *status = VIRTIO_STATUS_ACKNOWLEDGE | VIRTIO_STATUS_DRIVER;

                uint32_t desc_size  = 16 * VIRTQ_SIZE;
                uint32_t avail_size = 6 + 2 * VIRTQ_SIZE;
                uint32_t pad        = 4096 - ((desc_size + avail_size) % 4096);
                uint32_t used_size  = 6 + 8 * VIRTQ_SIZE;
                uint32_t total      = desc_size + avail_size + pad + used_size;

                uint64_t queue_base = bump_allocate(total, 4096);
                in_desc  = (volatile struct virtq_desc *)queue_base;
                in_avail = (volatile struct virtq_avail *)(queue_base + desc_size);
                in_used  = (volatile struct virtq_used *)(queue_base + desc_size + avail_size + pad);
                
                in_events = (struct virtio_input_event *)bump_allocate(sizeof(struct virtio_input_event) * VIRTQ_SIZE, 64);

                if (*version == 2) {
                    volatile uint32_t *drv_feat_sel = (volatile uint32_t *)(base + 0x024);
                    volatile uint32_t *drv_feat     = (volatile uint32_t *)(base + 0x020);
                    volatile uint32_t *q_desc_low   = (volatile uint32_t *)(base + VIRTIO_REG_QUEUE_DESC_LOW);
                    volatile uint32_t *q_desc_high  = (volatile uint32_t *)(base + VIRTIO_REG_QUEUE_DESC_HIGH);
                    volatile uint32_t *q_avail_low  = (volatile uint32_t *)(base + VIRTIO_REG_QUEUE_AVAIL_LOW);
                    volatile uint32_t *q_avail_high = (volatile uint32_t *)(base + VIRTIO_REG_QUEUE_AVAIL_HIGH);
                    volatile uint32_t *q_used_low   = (volatile uint32_t *)(base + VIRTIO_REG_QUEUE_USED_LOW);
                    volatile uint32_t *q_used_high  = (volatile uint32_t *)(base + VIRTIO_REG_QUEUE_USED_HIGH);
                    volatile uint32_t *q_ready      = (volatile uint32_t *)(base + VIRTIO_REG_QUEUE_READY);

                    *drv_feat_sel = 0; *drv_feat = 0;
                    *drv_feat_sel = 1; *drv_feat = 1; 
                    *status = VIRTIO_STATUS_ACKNOWLEDGE | VIRTIO_STATUS_DRIVER | VIRTIO_STATUS_FEATURES_OK;

                    *q_sel = 0; 
                    *q_num = VIRTQ_SIZE;
                    *q_desc_low = (uint32_t)(uint64_t)in_desc;   *q_desc_high = 0;
                    *q_avail_low = (uint32_t)(uint64_t)in_avail; *q_avail_high = 0;
                    *q_used_low = (uint32_t)(uint64_t)in_used;   *q_used_high = 0;
                    *q_ready = 1;
                    
                    for (int j = 0; j < VIRTQ_SIZE; j++) {
                        in_desc[ j ].addr = (uint64_t)&in_events[ j ];
                        in_desc[ j ].len = sizeof(struct virtio_input_event);
                        in_desc[ j ].flags = VIRTQ_DESC_F_WRITE; 
                        in_desc[ j ].next = 0;
                        in_avail->ring[ j ] = j;
                    }
                    in_avail->idx = VIRTQ_SIZE;
                    
                    for (uint64_t a = (uint64_t)in_desc & ~63ULL; a < (uint64_t)in_desc + sizeof(struct virtq_desc) * VIRTQ_SIZE; a += 64)
                        __asm__ volatile("dc cvac, %0" :: "r"(a) : "memory");

                    for (uint64_t a = (uint64_t)in_avail->ring & ~63ULL; a < (uint64_t)in_avail->ring + sizeof(uint16_t) * VIRTQ_SIZE; a += 64)
                        __asm__ volatile("dc cvac, %0" :: "r"(a) : "memory");

                    __asm__ volatile("dc cvac, %0" :: "r"((uint64_t)&in_avail->idx & ~63ULL) : "memory");
                    __asm__ volatile("dsb sy" ::: "memory");
                    
                    volatile uint32_t *notify_reg = (volatile uint32_t *)(base + VIRTIO_REG_QUEUE_NOTIFY);
                    *notify_reg = 0;

                    *status = VIRTIO_STATUS_ACKNOWLEDGE | VIRTIO_STATUS_DRIVER | VIRTIO_STATUS_FEATURES_OK | VIRTIO_STATUS_DRIVER_OK;
                }
            } 
            else if (*devid == VIRTIO_DEV_GPU) {
                gpu_mmio_base = base;
                volatile uint32_t *status = (volatile uint32_t *)(base + VIRTIO_REG_STATUS);
                volatile uint32_t *q_sel  = (volatile uint32_t *)(base + VIRTIO_REG_QUEUE_SEL);
                volatile uint32_t *q_num  = (volatile uint32_t *)(base + VIRTIO_REG_QUEUE_NUM);
                *status = 0; *status = VIRTIO_STATUS_ACKNOWLEDGE | VIRTIO_STATUS_DRIVER;

                uint64_t queue_base = bump_allocate(16*VIRTQ_SIZE + 6+2*VIRTQ_SIZE + 4096 + 6+8*VIRTQ_SIZE, 4096);
                gpu_desc  = (volatile struct virtq_desc *)queue_base;
                gpu_avail = (volatile struct virtq_avail *)(queue_base + 16*VIRTQ_SIZE);
                gpu_used  = (volatile struct virtq_used *)(queue_base + 16*VIRTQ_SIZE + 6+2*VIRTQ_SIZE + (4096 - ((16*VIRTQ_SIZE + 6+2*VIRTQ_SIZE) % 4096)));

                if (*version == 2) {
                    volatile uint32_t *drv_feat_sel = (volatile uint32_t *)(base + 0x024); volatile uint32_t *drv_feat = (volatile uint32_t *)(base + 0x020);
                    volatile uint32_t *q_desc_low = (volatile uint32_t *)(base + VIRTIO_REG_QUEUE_DESC_LOW); volatile uint32_t *q_desc_high = (volatile uint32_t *)(base + VIRTIO_REG_QUEUE_DESC_HIGH);
                    volatile uint32_t *q_avail_low = (volatile uint32_t *)(base + VIRTIO_REG_QUEUE_AVAIL_LOW); volatile uint32_t *q_avail_high = (volatile uint32_t *)(base + VIRTIO_REG_QUEUE_AVAIL_HIGH);
                    volatile uint32_t *q_used_low = (volatile uint32_t *)(base + VIRTIO_REG_QUEUE_USED_LOW); volatile uint32_t *q_used_high = (volatile uint32_t *)(base + VIRTIO_REG_QUEUE_USED_HIGH);
                    volatile uint32_t *q_ready = (volatile uint32_t *)(base + VIRTIO_REG_QUEUE_READY);
                    *drv_feat_sel = 0; *drv_feat = 0; *drv_feat_sel = 1; *drv_feat = 1; 
                    *status = VIRTIO_STATUS_ACKNOWLEDGE | VIRTIO_STATUS_DRIVER | VIRTIO_STATUS_FEATURES_OK;
                    *q_sel = 0; *q_num = VIRTQ_SIZE;
                    *q_desc_low = (uint32_t)(uint64_t)gpu_desc; *q_desc_high = 0; *q_avail_low = (uint32_t)(uint64_t)gpu_avail; *q_avail_high = 0; *q_used_low = (uint32_t)(uint64_t)gpu_used; *q_used_high = 0;
                    *q_ready = 1;
                    *status = VIRTIO_STATUS_ACKNOWLEDGE | VIRTIO_STATUS_DRIVER | VIRTIO_STATUS_FEATURES_OK | VIRTIO_STATUS_DRIVER_OK;
                }
                gpu_init();
            }
        }
    }
    uart_print("[ KERNEL ] VirtIO probe complete\n");
}