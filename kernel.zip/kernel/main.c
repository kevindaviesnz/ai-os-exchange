#include "os_types.h"
#include "os_virtio.h"

extern void mmu_init_tables(void);
extern void virtio_probe_and_init(void);
extern void uart_print(const char *str);

extern char _el0_text_start[];
extern char _el0_stack_top[];

void kernel_main(void) {
    mmu_init_tables();
    uart_print("[KERNEL] MMU online\n");

    virtio_probe_and_init();

    uart_print("[KERNEL] Dropping to EL0...\n");

    __asm__ volatile(
        /* SPSR_EL1 = 0: drop to EL0t, all interrupts unmasked */
        "msr spsr_el1, xzr\n\t"
        /* FIX: use ldr literal instead of adr — adr is ±1MB PC-relative
           and shell_main may be beyond that range */
        "ldr x0, =_el0_text_start\n\t"
        "msr elr_el1, x0\n\t"
        "ldr x0, =_el0_stack_top\n\t"
        "msr sp_el0, x0\n\t"
        "eret\n\t"
        :
        :
        : "x0"
    );

    while (1) {
        __asm__ volatile("wfi");
    }
}